import java.io.File;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.util.ArrayList;
import java.util.List;

import java.awt.image.BufferedImage;

public class SampleWindow {
    private static JFrame sample1 = null;
    private static MenuBackground samplePanel1;

    public void showSamples(JTextField highlightInput, JTextField primaryInput, JTextField secondaryInput, 
		JTextField slotInput, JTextField accentInput, JTextField borderInput) {
        String currentDirect = System.getProperty("user.dir");

        String highlightColor = "#ffffff";
        String borderColor = "#ffffff";
        String accentColor = "#ffffff";
        String slotColor = "#ffffff";
        String secondaryColor = "#ffffff";
        String primaryColor = "#ffffff";

        boolean highlightCodeExists;
        boolean primaryCodeExists;
        boolean secondaryCodeExists;
        boolean slotCodeExists;
        boolean accentCodeExists;
        boolean borderCodeExists;

        String highlighti = highlightInput.getText().trim();
        String primaryi = primaryInput.getText().trim();
        String secondaryi = secondaryInput.getText().trim();
        String sloti = slotInput.getText().trim();
        String accenti = accentInput.getText().trim();
        String borderi = borderInput.getText().trim();
            if (!highlighti.isEmpty() && highlighti.length() == 7) {
                highlightCodeExists = true;
                try {
                    Color new1Color = Color.decode(highlighti);
                } catch (NumberFormatException n) {
                    highlightCodeExists = false;
                }
            } else {
                highlightCodeExists = false;
            }
            if (!primaryi.isEmpty() && primaryi.length() == 7) {
                primaryCodeExists = true;
                try {
                    Color new2Color = Color.decode(primaryi);
                } catch (NumberFormatException n) {
                    primaryCodeExists = false;
                }
            } else {
                primaryCodeExists = false;
            }
            if (!secondaryi.isEmpty() && secondaryi.length() == 7) {
                secondaryCodeExists = true;
                try {
                    Color new3Color = Color.decode(secondaryi);
                } catch (NumberFormatException n) {
                    secondaryCodeExists = false;
                }
            } else {
                secondaryCodeExists = false;
            }
            if (!sloti.isEmpty() && sloti.length() == 7) {
                slotCodeExists = true;
            	try {
            	    Color new4Color = Color.decode(sloti);
            	} catch (NumberFormatException n) {
            	    slotCodeExists = false;
            	}
            } else {
                slotCodeExists = false;
            }
            if (!accenti.isEmpty() && accenti.length() == 7) {
                accentCodeExists = true;
                try {
                    Color new5Color = Color.decode(accenti);
                } catch (NumberFormatException n) {
                    accentCodeExists = false;
                }
            } else {
                accentCodeExists = false;
            }
            if (!borderi.isEmpty() && borderi.length() == 7) {
                borderCodeExists = true;
                try {
                    Color new6Color = Color.decode(borderi);
                } catch (NumberFormatException n) {
                    borderCodeExists = false;
                }
            } else {
                borderCodeExists = false;
            }
            if (highlightCodeExists == false) {
            } else if (primaryCodeExists == false) {
            } else if (secondaryCodeExists == false) {
            } else if (accentCodeExists == false) {
            } else if (slotCodeExists == false) {
            } else if (borderCodeExists == false) {
            } else {
                highlightColor = highlightInput.getText();
                borderColor = borderInput.getText();
                accentColor = accentInput.getText();
                slotColor = slotInput.getText();
                secondaryColor = secondaryInput.getText();
                primaryColor = primaryInput.getText();
			}

            List<String> rawColors2 = List.of(borderColor, accentColor, slotColor, secondaryColor,
                primaryColor);
			
			String newPackName = "cSampleGUIResources";
			File newPackFolder = new File(currentDirect, newPackName);
			System.out.println("File Prepared: " + newPackFolder);
			Path ptOrignalAssets = Paths.get(currentDirect + "/sampleGUIResources");
			Path ptNewPack = Paths.get(currentDirect + "/cSampleGUIResources");

			try {
				copyFile(ptOrignalAssets, ptNewPack);
			} catch (IOException e) {
				e.printStackTrace();
			}

            try {
                List<String> sample_Sprite = new ArrayList<>();
                sample_Sprite.add((currentDirect
                        + "/cSampleGUIResources/sample_ui4.png"));
				sample_Sprite.add((currentDirect
                        + "/cSampleGUIResources/sample_uia.png"));
				sample_Sprite.add((currentDirect
                        + "/cSampleGUIResources/sample_ui3.png"));
				sample_Sprite.add((currentDirect
                        + "/cSampleGUIResources/sample_ui2.png"));
				sample_Sprite.add((currentDirect
                        + "/cSampleGUIResources/sample_ui1.png"));
                File sample_SpritePath = new File(currentDirect
                        + "/cSampleGUIResources/sample_ui.png");
                ImageIO.write(GUIColorizer.createNewSprite(sample_Sprite, rawColors2), "PNG",
						sample_SpritePath);
                for (String s : sample_Sprite) {
                    new File(s).delete();
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }

        if (sample1 == null || !sample1.isVisible()) {
            sample1 = new JFrame("Nullcore - SAMPLE");
            sample1.setSize(564, 538);
            sample1.setLocationRelativeTo(null);
            sample1.setResizable(false);
            samplePanel1 = new MenuBackground(currentDirect + "/sampleBackground.png");
            samplePanel1.setLayout(new FlowLayout());
        } else {
            sample1.dispose();
            sample1 = new JFrame("Nullcore - SAMPLE");
            sample1.setSize(564, 538);
            sample1.setLocationRelativeTo(null);
            sample1.setLocation(600, 0 );
            sample1.setResizable(false);
            samplePanel1 = new MenuBackground(currentDirect + "/sampleBackground.png");
            samplePanel1.setLayout(new FlowLayout());
        }
        ImageIcon icon = new ImageIcon (currentDirect + "/cSampleGUIResources/sample_ui.png");
        JLabel spriteIcon = new JLabel();
        icon.getImage().flush();
        spriteIcon.setIcon(icon);
        samplePanel1.add(spriteIcon);

        sample1.setContentPane(samplePanel1);
        sample1.setVisible(true);
    }

	public static void copyFile(Path source, Path target) throws IOException {
		Files.walkFileTree(source, new SimpleFileVisitor<Path>() {
			@Override
			public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes bfa) throws IOException {
				Path targetPath = target.resolve(source.relativize(dir));
				if (!Files.exists(targetPath)) {
					Files.createDirectories(targetPath);
				}
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFile(Path file, BasicFileAttributes bfa) throws IOException {
				Files.copy(file, target.resolve(source.relativize(file)), REPLACE_EXISTING);
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
				System.err.println("Failed to visit the following file: " + file + " - " + exc.getMessage());
				return FileVisitResult.CONTINUE;
			}
		});
	}
}

class MenuBackground extends JPanel {
	private BufferedImage backgroundSprite;

	public MenuBackground(String spritePath) {
		try {
			backgroundSprite = ImageIO.read(new File(spritePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (backgroundSprite != null) {
			g.drawImage(backgroundSprite, 0, 0, getWidth(), getHeight(), this);
		}
	}
}

