// -= PROGRAM =-
// Program Name: NullcoreMain (Part of "Project Nullcore ALPHA 2.0")
// Date Created: 11/8/2025
// Created by: EnderTheIdiot
//
// -= INFO =-
// This is the main program where the main function of the program is stored. Any changes made 
// to this code could cause the program to malfunction. Proceed with caution. If the program 
// breaks, simply delete this program, and redownload it from the platform you obtained it.
// 

import java.io.File;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.util.ArrayList;
import java.util.List;

public class NullcoreMain {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			// [MENU] - Obtains the directory of the program
			String currentDirect = System.getProperty("user.dir");

			// [MENU] - Creates the window for the menu
			JFrame menu1 = new JFrame("Nullcore - MAIN MENU");
			menu1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			menu1.setSize(564, 538);
			menu1.setLocationRelativeTo(null);
			menu1.setResizable(false);
			MenuBackground menuPanel1 = new MenuBackground(currentDirect + "/program_assets/backgrounds/mainmenuBackground.png");
			menuPanel1.setLayout(null);

			// [MENU] - Loads the new system font
			Font systemFont = NullcoreFont.loadSystemFont(currentDirect + "/program_assets/fonts/PressStart2P-Regular.ttf", 14f);

			// [MENU] - Shows errors in the menu screen
			JLabel errorLabel = new JLabel();
			errorLabel.setBounds(260, 337, 160, 20);
			errorLabel.setFont(systemFont);
			menuPanel1.add(errorLabel);
			JLabel infoLabel = new JLabel("Insert Hexcodes for GUI colors below! (ex. #FFE7E7)");
			infoLabel.setForeground(Color.WHITE);
			infoLabel.setBounds(82, 125, 480, 20);
			infoLabel.setFont(systemFont);
			menuPanel1.add(infoLabel);
			JTextField highlightInput = new JTextField(20);
			highlightInput.setText("#ffffff");
			highlightInput.setBounds(106, 169, 160, 25);
			menuPanel1.add(highlightInput);
			JTextField primaryInput = new JTextField(20);
			primaryInput.setText("#ffffff");
			primaryInput.setBounds(105, 202, 160, 25);
			menuPanel1.add(primaryInput);
			JTextField secondaryInput = new JTextField(20);
			secondaryInput.setText("#ffffff");
			secondaryInput.setBounds(105, 235, 160, 25);
			menuPanel1.add(secondaryInput);
			JTextField slotInput = new JTextField(20);
			slotInput.setText("#ffffff");
			slotInput.setBounds(105, 268, 160, 25);
			menuPanel1.add(slotInput);
			JTextField accentInput = new JTextField(20);
			accentInput.setText("#ffffff");
			accentInput.setBounds(105, 301, 160, 25);
			menuPanel1.add(accentInput);
			JTextField borderInput = new JTextField(20);
			borderInput.setText("#ffffff");
			borderInput.setBounds(105, 334, 160, 25);
			menuPanel1.add(borderInput);

			// [MENU] Sets up the input for the custom pack name
			JLabel nameLabel = new JLabel("Pack Name");
			nameLabel.setForeground(Color.WHITE);
			nameLabel.setBounds(443, 424, 480, 20);
			nameLabel.setFont(systemFont);
			menuPanel1.add(nameLabel);
			JLabel nameLabel2 = new JLabel("(10 Char)");
			nameLabel2.setForeground(Color.WHITE);
			nameLabel2.setBounds(445, 468, 480, 20);
			nameLabel2.setFont(systemFont);
			menuPanel1.add(nameLabel2);
			JTextField nameInput = new JTextField(5);
			nameInput.setBounds(422, 445, 120, 25);
			menuPanel1.add(nameInput);


			// [MENU] - Sets the current color for the buttons (BROKEN)
			Color ButtonColor = Color.decode("#1E1E1E");

			// [MENU] - Creates the viewable samples of hexcode colors (IN-DEV)
			JButton sample1 = new JButton();
			sample1.setBounds(69, 171, 18, 18);
			sample1.setBackground(Color.DARK_GRAY);
			JButton sample2 = new JButton();
			sample2.setBounds(69, 204, 18, 18);
			sample2.setBackground(Color.DARK_GRAY);
			JButton sample3 = new JButton();
			sample3.setBounds(69, 237, 18, 18);
			sample3.setBackground(Color.DARK_GRAY);
			JButton sample4 = new JButton();
			sample4.setBounds(69, 270, 18, 18);
			sample4.setBackground(Color.DARK_GRAY);
			JButton sample5 = new JButton();
			sample5.setBounds(69, 303, 18, 18);
			sample5.setBackground(Color.DARK_GRAY);
			JButton sample6 = new JButton();
			sample6.setBounds(69, 336, 18, 18);
			sample6.setBackground(Color.DARK_GRAY);

			// [MENU] - Adds the viewable samples of hexcode colors (IN_DEV)
			menuPanel1.add(sample1);
			menuPanel1.add(sample2);
			menuPanel1.add(sample3);
			menuPanel1.add(sample4);
			menuPanel1.add(sample5);
			menuPanel1.add(sample6);

			// [MENU] - Button for refreshing the samples (IN-DEV)
			JButton sampleRefreshButton = new JButton("Refresh Samples");
			sampleRefreshButton.setBounds(105, 390, 130, 20);
			sampleRefreshButton.setBackground(ButtonColor);
			sampleRefreshButton.setFont(systemFont);
			sampleRefreshButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent a) {
					String highlighti = highlightInput.getText().trim();
					String primaryi = primaryInput.getText().trim();
					String secondaryi = secondaryInput.getText().trim();
					String sloti = slotInput.getText().trim();
					String accenti = accentInput.getText().trim();
					String borderi = borderInput.getText().trim();
					// [SAMPLE] - Decodes the color input in the GUI to show what the "highlight" color will look like
					if (!highlighti.isEmpty() && highlighti.length() == 7) {
						try {
							Color new1Color = Color.decode(highlighti);
							sample1.setBackground(new1Color);
							sample1.setOpaque(true);
							sample1.setContentAreaFilled(true);
							sample1.setBorderPainted(false);
							sample1.repaint();
						} catch (NumberFormatException n) {
							sample1.setBackground(Color.DARK_GRAY);
							sample1.setOpaque(true);
							sample1.setContentAreaFilled(true);
							sample1.setBorderPainted(false);
							sample1.repaint();
						}
					}
					// [SAMPLE] - Decodes the color input in the GUI to show what the "primary" color will look like
					if (!primaryi.isEmpty() && primaryi.length() == 7) {
						try {
							Color new2Color = Color.decode(primaryi);
							sample2.setBackground(new2Color);
							sample2.setOpaque(true);
							sample2.setContentAreaFilled(true);
							sample2.setBorderPainted(false);
							sample2.repaint();
						} catch (NumberFormatException n) {
							sample2.setBackground(Color.DARK_GRAY);
							sample2.setOpaque(true);
							sample2.setContentAreaFilled(true);
							sample2.setBorderPainted(false);
							sample2.repaint();
						}
					}
					// [SAMPLE] - Decodes the color input in the GUI to show what the "secondary" color will look like
					if (!secondaryi.isEmpty() && secondaryi.length() == 7) {
						try {
							Color new3Color = Color.decode(secondaryi);
							sample3.setBackground(new3Color);
							sample3.setOpaque(true);
							sample3.setContentAreaFilled(true);
							sample3.setBorderPainted(false);
							sample3.repaint();
						} catch (NumberFormatException n) {
							sample3.setBackground(Color.DARK_GRAY);
							sample3.setOpaque(true);
							sample3.setContentAreaFilled(true);
							sample3.setBorderPainted(false);
							sample3.repaint();
						}
					}
					// [SAMPLE] - Decodes the color input in the GUI to show what the "slot" color will look like
					if (!sloti.isEmpty() && sloti.length() == 7) {
						try {
							Color new4Color = Color.decode(sloti);
							sample4.setBackground(new4Color);
							sample4.setOpaque(true);
							sample4.setContentAreaFilled(true);
							sample4.setBorderPainted(false);
							sample4.repaint();
						} catch (NumberFormatException n) {
							sample4.setBackground(Color.DARK_GRAY);
							sample4.setOpaque(true);
							sample4.setContentAreaFilled(true);
							sample4.setBorderPainted(false);
							sample4.repaint();
						}
					}
					// [SAMPLE] - Decodes the color input in the GUI to show what the "accent" color will look like
					if (!accenti.isEmpty() && accenti.length() == 7) {
						try {
							Color new5Color = Color.decode(accenti);
							sample5.setBackground(new5Color);
							sample5.setOpaque(true);
							sample5.setContentAreaFilled(true);
							sample5.setBorderPainted(false);
							sample5.repaint();
						} catch (NumberFormatException n) {
							sample5.setBackground(Color.DARK_GRAY);
							sample5.setOpaque(true);
							sample5.setContentAreaFilled(true);
							sample5.setBorderPainted(false);
							sample5.repaint();
						}
					}
					// [SAMPLE] - Decodes the color input in the GUI to show what the "border" color will look like
					if (!borderi.isEmpty() && borderi.length() == 7) {
						try {
							Color new6Color = Color.decode(borderi);
							sample6.setBackground(new6Color);
							sample6.setOpaque(true);
							sample6.setContentAreaFilled(true);
							sample6.setBorderPainted(false);
							sample6.repaint();
						} catch (NumberFormatException n) {
							sample6.setBackground(Color.DARK_GRAY);
							sample6.setOpaque(true);
							sample6.setContentAreaFilled(true);
							sample6.setBorderPainted(false);
							sample6.repaint();
						}
					}
					NullcoreSampler newSampleWindow = new NullcoreSampler();
					newSampleWindow.showSamples(highlightInput, primaryInput, secondaryInput, slotInput, accentInput, borderInput);
				}
			});
			menuPanel1.add(sampleRefreshButton); 

			// [MENU] - Button for creating the new pack
			JButton createPack = new JButton("Create Pack");
			createPack.setBounds(330, 390, 110, 20);
			createPack.setBackground(ButtonColor);
			createPack.setFont(systemFont);
			createPack.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent a) {
					boolean highlightCodeExists;
					boolean primaryCodeExists;
					boolean secondaryCodeExists;
					boolean slotCodeExists;
					boolean accentCodeExists;
					boolean borderCodeExists;
					String highlighti = highlightInput.getText().trim();
					String primaryi = primaryInput.getText().trim();
					String secondaryi = secondaryInput.getText().trim();
					String sloti = slotInput.getText().trim();
					String accenti = accentInput.getText().trim();
					String borderi = borderInput.getText().trim();
					if (!highlighti.isEmpty() && highlighti.length() == 7) {
						highlightCodeExists = true;
						try {
							Color new1Color = Color.decode(highlighti);
							sample1.setBackground(new1Color);
						} catch (NumberFormatException n) {
							highlightCodeExists = false;
						}
					} else {
						highlightCodeExists = false;
					}
					if (!primaryi.isEmpty() && primaryi.length() == 7) {
						primaryCodeExists = true;
						try {
							Color new2Color = Color.decode(primaryi);
							sample2.setBackground(new2Color);
						} catch (NumberFormatException n) {
							primaryCodeExists = false;
						}
					} else {
						primaryCodeExists = false;
					}
					if (!secondaryi.isEmpty() && secondaryi.length() == 7) {
						secondaryCodeExists = true;
						try {
							Color new3Color = Color.decode(secondaryi);
							sample3.setBackground(new3Color);
						} catch (NumberFormatException n) {
							secondaryCodeExists = false;
						}
					} else {
						secondaryCodeExists = false;
					}
					if (!sloti.isEmpty() && sloti.length() == 7) {
						slotCodeExists = true;

						try {
							Color new4Color = Color.decode(sloti);
							sample4.setBackground(new4Color);
						} catch (NumberFormatException n) {
							slotCodeExists = false;
						}
					} else {
						slotCodeExists = false;
					}
					if (!accenti.isEmpty() && accenti.length() == 7) {
						accentCodeExists = true;
						try {
							Color new5Color = Color.decode(accenti);
							sample5.setBackground(new5Color);
						} catch (NumberFormatException n) {
							accentCodeExists = false;
						}
					} else {
						accentCodeExists = false;
					}
					if (!borderi.isEmpty() && borderi.length() == 7) {
						borderCodeExists = true;
						try {
							Color new6Color = Color.decode(borderi);
							sample6.setBackground(new6Color);
						} catch (NumberFormatException n) {
							borderCodeExists = false;
						}
					} else {
						borderCodeExists = false;
					}
					if (highlightCodeExists == false) {
						errorLabel.setText("Error: highlight code is not a valid Hex Code");
					} else if (primaryCodeExists == false) {
						errorLabel.setText("Error: Current primary code is not a valid Hex Code");
					} else if (secondaryCodeExists == false) {
						errorLabel.setText("Error: Current secondary code is not a valid Hex Code");
					} else if (accentCodeExists == false) {
						errorLabel.setText("Error: Current accent code is not a valid Hex Code");
					} else if (slotCodeExists == false) {
						errorLabel.setText("Error: Current slot code is not a valid Hex Code");
					} else if (borderCodeExists == false) {
						errorLabel.setText("Error: Current border code is not a valid Hex Code");
					} else {

						// [PACKAGE] - Establishes directories
						String newPackName = "new_smc_pack";
						File newPackFolder = new File(currentDirect, newPackName);
						System.out.println("File Prepared: " + newPackFolder);
						Path ptOrignalAssets = Paths.get(currentDirect + "/base_smc_pack");
						Path ptNewPack = Paths.get(currentDirect + "/new_smc_pack");

						// [SPRITE CREATION] - Obtains the colors for the sprites
						String highlightColor = highlightInput.getText();
						String borderColor = borderInput.getText();
						String accentColor = accentInput.getText();
						String slotColor = slotInput.getText();
						String secondaryColor = secondaryInput.getText();
						String primaryColor = primaryInput.getText();

						// [PACKAGE] - Copys the orignial Assets
						try {
							copyFile(ptOrignalAssets, ptNewPack);
						} catch (IOException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - Establishes all possible color palletes for the pack
						List<String> rawColors2 = List.of(borderColor, accentColor, slotColor, secondaryColor,
								primaryColor);
						List<String> rawColors4 = List.of(borderColor, slotColor, secondaryColor, primaryColor);
						List<String> rawColors5 = List.of(borderColor, slotColor);
						List<String> rawColors6 = List.of(borderColor, secondaryColor);
						List<String> rawColors7 = List.of(borderColor, primaryColor);
						List<String> rawColors9 = List.of(highlightColor, secondaryColor);
						List<String> rawColors10 = List.of(highlightColor, primaryColor);
						List<String> rawColors11 = List.of(highlightColor, borderColor);
						List<String> rawColors12 = List.of(highlightColor);
						List<String> rawColors13 = List.of(borderColor);
						List<String> rawColors14 = List.of(borderColor, slotColor, secondaryColor);
						List<String> rawColors15 = List.of(highlightColor, slotColor, secondaryColor);
						List<String> rawColors16 = List.of(borderColor, primaryColor, secondaryColor);
						List<String> rawColors17 = List.of(borderColor, slotColor, secondaryColor);
						List<String> rawColorsPack = List.of(highlightColor, borderColor, secondaryColor);

						// [SPRITE CREATION] - Creates the Icon
						try {
							// [SPRITE CREATION] - "pack.png" Sprite
							List<String> packSprite = new ArrayList<>();
							packSprite.add((currentDirect + "/new_smc_pack/pack_ui3.png"));
							packSprite.add((currentDirect + "/new_smc_pack/pack_ui2.png"));
							packSprite.add((currentDirect + "/new_smc_pack/pack_ui1.png"));
							File packSpritePath = new File(currentDirect + "/new_smc_pack/pack.png");
							ImageIO.write(NullcoreColor.createNewSprite(packSprite, rawColorsPack), "PNG",
									packSpritePath);
							for (String s : packSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - Creates All Container GUI Sprites that don't include
						// extra sprites (connected sprites in sprites folder)
						try {
							// [SPRITE CREATION] - Loads the sprites in the folder
							List<BufferedImage> allSprites = loadSpritesFromFolder(
									currentDirect + "/new_smc_pack/assets/minecraft/textures/gui/container");
							if (allSprites.size() < 5) {
								System.out.println("No sprites found in Container file!");
								return;
							}
							// [SPRITE CREATION] - "crafting_table.png" Sprite
							List<String> crafting_tableSprite = new ArrayList<>();
							crafting_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafting_table_ui4.png"));
							crafting_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafting_table_ui3.png"));
							crafting_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafting_table_ui2.png"));
							crafting_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafting_table_ui1.png"));
							File crafting_tableSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafting_table.png");
							ImageIO.write(NullcoreColor.createNewSprite(crafting_tableSprite, rawColors4), "PNG",
									crafting_tableSpritePath);
							for (String s : crafting_tableSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “dispenser.png" Sprite
							List<String> dispenserSprite = new ArrayList<>();
							dispenserSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/dispenser_ui4.png"));
							dispenserSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/dispenser_ui3.png"));
							dispenserSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/dispenser_ui2.png"));
							dispenserSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/dispenser_ui1.png"));
							File dispenserSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/dispenser.png");
							ImageIO.write(NullcoreColor.createNewSprite(dispenserSprite, rawColors4), "PNG",
									dispenserSpritePath);
							for (String s : dispenserSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “generic_54.png" Sprite
							List<String> generic_54Sprite = new ArrayList<>();
							generic_54Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/generic_54_ui4.png"));
							generic_54Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/generic_54_ui3.png"));
							generic_54Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/generic_54_ui2.png"));
							generic_54Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/generic_54_ui1.png"));
							File generic_54SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/generic_54.png");
							ImageIO.write(NullcoreColor.createNewSprite(generic_54Sprite, rawColors4), "PNG",
									generic_54SpritePath);
							for (String s : generic_54Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “hopper.png" Sprite
							List<String> hopperSprite = new ArrayList<>();
							hopperSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/hopper_ui4.png"));
							hopperSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/hopper_ui3.png"));
							hopperSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/hopper_ui2.png"));
							hopperSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/hopper_ui1.png"));
							File hopperSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/hopper.png");
							ImageIO.write(NullcoreColor.createNewSprite(hopperSprite, rawColors4), "PNG",
									hopperSpritePath);
							for (String s : hopperSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “shulker_box.png" Sprite
							List<String> shulker_boxSprite = new ArrayList<>();
							shulker_boxSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/shulker_box_ui4.png"));
							shulker_boxSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/shulker_box_ui3.png"));
							shulker_boxSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/shulker_box_ui2.png"));
							shulker_boxSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/shulker_box_ui1.png"));
							File shulker_boxSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/shulker_box.png");
							ImageIO.write(NullcoreColor.createNewSprite(shulker_boxSprite, rawColors4), "PNG",
									shulker_boxSpritePath);
							for (String s : shulker_boxSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Recipe Book Sprites
						try {
							// [SPRITE CREATION] - “recipe_book.png" Sprite
							List<String> recipe_bookSprite = new ArrayList<>();
							recipe_bookSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/recipe_book_ui4.png"));
							recipe_bookSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/recipe_book_ui3.png"));
							recipe_bookSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/recipe_book_ui2.png"));
							recipe_bookSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/recipe_book_ui1.png"));
							File recipe_bookSpritePath = new File(
									currentDirect + "/new_smc_pack/assets/minecraft/textures/recipe_book.png");
							ImageIO.write(NullcoreColor.createNewSprite(recipe_bookSprite, rawColors4), "PNG",
									recipe_bookSpritePath);
							for (String s : recipe_bookSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “button_highlighted.png" Sprite
							List<String> button_highlightedSprite = new ArrayList<>();
							button_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/button_highlighted_ui3.png"));
							button_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/button_highlighted_ui2.png"));
							button_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/button_highlighted_ui1.png"));
							File button_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/button_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(button_highlightedSprite, rawColors15), "PNG",
									button_highlightedSpritePath);
							for (String s : button_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “button.png" Sprite
							List<String> buttonSprite = new ArrayList<>();
							buttonSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/button_ui3.png"));
							buttonSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/button_ui2.png"));
							buttonSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/button_ui1.png"));
							File buttonSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/button.png");
							ImageIO.write(NullcoreColor.createNewSprite(buttonSprite, rawColors14), "PNG",
									buttonSpritePath);
							for (String s : buttonSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “crafting_overlay_disabled_highlighted.png" Sprite
							List<String> crafting_overlay_disabled_highlightedSprite = new ArrayList<>();
							crafting_overlay_disabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_disabled_highlighted_ui1.png"));
							crafting_overlay_disabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_disabled_highlighted_ui2.png"));
							File crafting_overlay_disabled_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_disabled_highlighted.png");
							ImageIO.write(
									NullcoreColor.createNewSprite(crafting_overlay_disabled_highlightedSprite,
											rawColors6),
									"PNG", crafting_overlay_disabled_highlightedSpritePath);
							for (String s : crafting_overlay_disabled_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “crafting_overlay_disabled.png" Sprite
							List<String> crafting_overlay_disabledSprite = new ArrayList<>();
							crafting_overlay_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_disabled_ui2.png"));
							crafting_overlay_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_disabled_ui1.png"));
							File crafting_overlay_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(crafting_overlay_disabledSprite, rawColors5),
									"PNG",
									crafting_overlay_disabledSpritePath);
							for (String s : crafting_overlay_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “crafting_overlay_highlighted.png" Sprite
							List<String> crafting_overlay_highlightedSprite = new ArrayList<>();
							crafting_overlay_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_highlighted_ui2.png"));
							crafting_overlay_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_highlighted_ui1.png"));
							File crafting_overlay_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(crafting_overlay_highlightedSprite, rawColors7),
									"PNG", crafting_overlay_highlightedSpritePath);
							for (String s : crafting_overlay_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “crafting_overlay.png" Sprite
							List<String> crafting_overlaySprite = new ArrayList<>();
							crafting_overlaySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_ui2.png"));
							crafting_overlaySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay_ui1.png"));
							File crafting_overlaySpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/crafting_overlay.png");
							ImageIO.write(NullcoreColor.createNewSprite(crafting_overlaySprite, rawColors6), "PNG",
									crafting_overlaySpritePath);
							for (String s : crafting_overlaySprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “filter_disabled_highlighted.png" Sprite
							List<String> filter_disabled_highlightedSprite = new ArrayList<>();
							filter_disabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_disabled_highlighted_ui2.png"));
							filter_disabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_disabled_highlighted_ui1.png"));
							File filter_disabled_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_disabled_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(filter_disabled_highlightedSprite, rawColors6),
									"PNG", filter_disabled_highlightedSpritePath);
							for (String s : filter_disabled_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “filter_disabled.png" Sprite
							List<String> filter_disabledSprite = new ArrayList<>();
							filter_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_disabled_ui2.png"));
							filter_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_disabled_ui1.png"));
							File filter_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(filter_disabledSprite, rawColors5), "PNG",
									filter_disabledSpritePath);
							for (String s : filter_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “filter_enabled_highlighted.png" Sprite
							List<String> filter_enabled_highlightedSprite = new ArrayList<>();
							filter_enabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_enabled_highlighted_ui2.png"));
							filter_enabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_enabled_highlighted_ui1.png"));
							File filter_enabled_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_enabled_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(filter_enabled_highlightedSprite, rawColors7),
									"PNG",
									filter_enabled_highlightedSpritePath);
							for (String s : filter_enabled_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “filter_enabled.png" Sprite
							List<String> filter_enabledSprite = new ArrayList<>();
							filter_enabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_enabled_ui2.png"));
							filter_enabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_enabled_ui1.png"));
							File filter_enabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/filter_enabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(filter_enabledSprite, rawColors6), "PNG",
									filter_enabledSpritePath);
							for (String s : filter_enabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “furnace_filter_disabled_highlighted.png" Sprite
							List<String> furnace_filter_disabled_highlightedSprite = new ArrayList<>();
							furnace_filter_disabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_disabled_highlighted_ui2.png"));
							furnace_filter_disabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_disabled_highlighted_ui1.png"));
							File furnace_filter_disabled_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_disabled_highlighted.png");
							ImageIO.write(
									NullcoreColor.createNewSprite(furnace_filter_disabled_highlightedSprite, rawColors6),
									"PNG", furnace_filter_disabled_highlightedSpritePath);
							for (String s : furnace_filter_disabled_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “furnace_filter_disabled.png" Sprite
							List<String> furnace_filter_disabledSprite = new ArrayList<>();
							furnace_filter_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_disabled_ui2.png"));
							furnace_filter_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_disabled_ui1.png"));
							File furnace_filter_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(furnace_filter_disabledSprite, rawColors5),
									"PNG",
									furnace_filter_disabledSpritePath);
							for (String s : furnace_filter_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “furnace_filter_enabled_highlighted.png" Sprite
							List<String> furnace_filter_enabled_highlightedSprite = new ArrayList<>();
							furnace_filter_enabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_enabled_highlighted_ui2.png"));
							furnace_filter_enabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_enabled_highlighted_ui1.png"));
							File furnace_filter_enabled_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_enabled_highlighted.png");
							ImageIO.write(
									NullcoreColor.createNewSprite(furnace_filter_enabled_highlightedSprite, rawColors7),
									"PNG", furnace_filter_enabled_highlightedSpritePath);
							for (String s : furnace_filter_enabled_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “furnace_filter_enabled.png" Sprite
							List<String> furnace_filter_enabledSprite = new ArrayList<>();
							furnace_filter_enabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_enabled_ui2.png"));
							furnace_filter_enabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_enabled_ui1.png"));
							File furnace_filter_enabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_filter_enabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(furnace_filter_enabledSprite, rawColors6), "PNG",
									furnace_filter_enabledSpritePath);
							for (String s : furnace_filter_enabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “furnace_overlay_disabled_highlighted.png" Sprite
							List<String> furnace_overlay_disabled_highlightedSprite = new ArrayList<>();
							furnace_overlay_disabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_disabled_highlighted_ui2.png"));
							furnace_overlay_disabled_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_disabled_highlighted_ui1.png"));
							File furnace_overlay_disabled_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_disabled_highlighted.png");
							ImageIO.write(
									NullcoreColor.createNewSprite(furnace_overlay_disabled_highlightedSprite,
											rawColors6),
									"PNG", furnace_overlay_disabled_highlightedSpritePath);
							for (String s : furnace_overlay_disabled_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “furnace_overlay_disabled.png" Sprite
							List<String> furnace_overlay_disabledSprite = new ArrayList<>();
							furnace_overlay_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_disabled_ui2.png"));
							furnace_overlay_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_disabled_ui1.png"));
							File furnace_overlay_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(furnace_overlay_disabledSprite, rawColors5),
									"PNG",
									furnace_overlay_disabledSpritePath);
							for (String s : furnace_overlay_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “furnace_overlay_highlighted.png" Sprite
							List<String> furnace_overlay_highlightedSprite = new ArrayList<>();
							furnace_overlay_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_highlighted_ui2.png"));
							furnace_overlay_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_highlighted_ui1.png"));
							File furnace_overlay_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(furnace_overlay_highlightedSprite, rawColors7),
									"PNG", furnace_overlay_highlightedSpritePath);
							for (String s : furnace_overlay_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “furnace_overlay.png" Sprite
							List<String> furnace_overlaySprite = new ArrayList<>();
							furnace_overlaySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_ui2.png"));
							furnace_overlaySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay_ui1.png"));
							File furnace_overlaySpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/furnace_overlay.png");
							ImageIO.write(NullcoreColor.createNewSprite(furnace_overlaySprite, rawColors6), "PNG",
									furnace_overlaySpritePath);
							for (String s : furnace_overlaySprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “overlay_recipe.png" Sprite
							List<String> overlay_recipeSprite = new ArrayList<>();
							overlay_recipeSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/overlay_recipe_ui3.png"));
							overlay_recipeSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/overlay_recipe_ui2.png"));
							overlay_recipeSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/overlay_recipe_ui1.png"));
							File overlay_recipeSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/overlay_recipe.png");
							ImageIO.write(NullcoreColor.createNewSprite(overlay_recipeSprite, rawColors14), "PNG",
									overlay_recipeSpritePath);
							for (String s : overlay_recipeSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “page_backward_highlighted.png" Sprite
							List<String> page_backward_highlightedSprite = new ArrayList<>();
							page_backward_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_backward_highlighted_ui2.png"));
							page_backward_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_backward_highlighted_ui1.png"));
							File page_backward_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_backward_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(page_backward_highlightedSprite, rawColors10),
									"PNG",
									page_backward_highlightedSpritePath);
							for (String s : page_backward_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “page_backward.png" Sprite
							List<String> page_backwardSprite = new ArrayList<>();
							page_backwardSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_backward_ui2.png"));
							page_backwardSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_backward_ui1.png"));
							File page_backwardSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_backward.png");
							ImageIO.write(NullcoreColor.createNewSprite(page_backwardSprite, rawColors7), "PNG",
									page_backwardSpritePath);
							for (String s : page_backwardSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “page_forward_highlighted.png" Sprite
							List<String> page_forward_highlightedSprite = new ArrayList<>();
							page_forward_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_forward_highlighted_ui2.png"));
							page_forward_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_forward_highlighted_ui1.png"));
							File page_forward_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_forward_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(page_forward_highlightedSprite, rawColors10),
									"PNG",
									page_forward_highlightedSpritePath);
							for (String s : page_forward_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “page_forward.png" Sprite
							List<String> page_forwardSprite = new ArrayList<>();
							page_forwardSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_forward_ui2.png"));
							page_forwardSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_forward_ui1.png"));
							File page_forwardSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/page_forward.png");
							ImageIO.write(NullcoreColor.createNewSprite(page_forwardSprite, rawColors7), "PNG",
									page_forwardSpritePath);
							for (String s : page_forwardSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “slot_craftable.png" Sprite
							List<String> slot_craftableSprite = new ArrayList<>();
							slot_craftableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_craftable_ui3.png"));
							slot_craftableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_craftable_ui2.png"));
							slot_craftableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_craftable_ui1.png"));
							File slot_craftableSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_craftable.png");
							ImageIO.write(NullcoreColor.createNewSprite(slot_craftableSprite, rawColors16), "PNG",
									slot_craftableSpritePath);
							for (String s : slot_craftableSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “slot_many_uncraftable.png" Sprite
							List<String> slot_many_uncraftableSprite = new ArrayList<>();
							slot_many_uncraftableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_many_uncraftable_ui3.png"));
							slot_many_uncraftableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_many_uncraftable_ui2.png"));
							slot_many_uncraftableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_many_uncraftable_ui1.png"));
							File slot_many_uncraftableSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_many_uncraftable.png");
							ImageIO.write(NullcoreColor.createNewSprite(slot_many_uncraftableSprite, rawColors17), "PNG",
									slot_many_uncraftableSpritePath);
							for (String s : slot_many_uncraftableSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “slot_uncraftable.png" Sprite
							List<String> slot_uncraftableSprite = new ArrayList<>();
							slot_uncraftableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_uncraftable_ui3.png"));
							slot_uncraftableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_uncraftable_ui2.png"));
							slot_uncraftableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_uncraftable_ui1.png"));
							File slot_uncraftableSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/slot_uncraftable.png");
							ImageIO.write(NullcoreColor.createNewSprite(slot_uncraftableSprite, rawColors17), "PNG",
									slot_uncraftableSpritePath);
							for (String s : slot_uncraftableSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_selected.png" Sprite
							List<String> tab_selectedSprite = new ArrayList<>();
							tab_selectedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/tab_selected_ui2.png"));
							tab_selectedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/tab_selected_ui1.png"));
							File tab_selectedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/tab_selected.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_selectedSprite, rawColors6), "PNG",
									tab_selectedSpritePath);
							for (String s : tab_selectedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab.png" Sprite
							List<String> tabSprite = new ArrayList<>();
							tabSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/tab_ui2.png"));
							tabSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/tab_ui1.png"));
							File tabSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/recipe_book/tab.png");
							ImageIO.write(NullcoreColor.createNewSprite(tabSprite, rawColors5), "PNG", tabSpritePath);
							for (String s : tabSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Anvil Sprites
						try {
							// [SPRITE CREATION] - "anvil.png" Sprite
							List<String> anvilSprite = new ArrayList<>();
							anvilSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/anvil_ui4.png"));
							anvilSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/anvil_uia.png"));
							anvilSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/anvil_ui3.png"));
							anvilSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/anvil_ui2.png"));
							anvilSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/anvil_ui1.png"));
							File anvilSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/anvil.png");
							ImageIO.write(NullcoreColor.createNewSprite(anvilSprite, rawColors2), "PNG",
									anvilSpritePath);
							for (String s : anvilSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “error.png" Sprite
							List<String> errorSprite = new ArrayList<>();
							errorSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/anvil/error_ui2.png"));
							errorSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/anvil/error_ui1.png"));
							File errorSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/anvil/error.png");
							ImageIO.write(NullcoreColor.createNewSprite(errorSprite, rawColors11), "PNG",
									errorSpritePath);
							for (String s : errorSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “text_field_enabled.png" Sprite
							List<String> text_field_enabledSprite = new ArrayList<>();
							text_field_enabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/anvil/text_field_enabled_ui2.png"));
							text_field_enabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/anvil/text_field_enabled_ui1.png"));
							File text_field_enabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/anvil/text_field_enabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(text_field_enabledSprite, rawColors9), "PNG",
									text_field_enabledSpritePath);
							for (String s : text_field_enabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “text_field_enabled.png" Sprite
							List<String> text_field_disabledSprite = new ArrayList<>();
							text_field_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/anvil/text_field_disabled_ui2.png"));
							text_field_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/anvil/text_field_disabled_ui1.png"));
							File text_field_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/anvil/text_field_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(text_field_disabledSprite, rawColors11), "PNG",
									text_field_disabledSpritePath);
							for (String s : text_field_disabledSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Beacon Sprites
						try {
							// [SPRITE CREATION] - "beacon.png" Sprite
							List<String> beaconSprite = new ArrayList<>();
							beaconSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/beacon_ui4.png"));
							beaconSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/beacon_ui3.png"));
							beaconSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/beacon_ui2.png"));
							beaconSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/beacon_ui1.png"));
							File beaconSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/beacon.png");
							ImageIO.write(NullcoreColor.createNewSprite(beaconSprite, rawColors4), "PNG",
									beaconSpritePath);
							for (String s : beaconSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “button_disabled.png" Sprite
							List<String> button_disabledSprite = new ArrayList<>();
							button_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_disabled_ui2.png"));
							button_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_disabled_ui1.png"));
							File button_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(button_disabledSprite, rawColors5), "PNG",
									button_disabledSpritePath);
							for (String s : button_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “button_highlighted.png" Sprite
							List<String> button_highlightedSprite = new ArrayList<>();
							button_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_highlighted_ui2.png"));
							button_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_highlighted_ui1.png"));
							File button_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(button_highlightedSprite, rawColors10), "PNG",
									button_highlightedSpritePath);
							for (String s : button_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “button_selected.png" Sprite
							List<String> button_selectedSprite = new ArrayList<>();
							button_selectedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_selected_ui2.png"));
							button_selectedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_selected_ui1.png"));
							File button_selectedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_selected.png");
							ImageIO.write(NullcoreColor.createNewSprite(button_selectedSprite, rawColors6), "PNG",
									button_selectedSpritePath);
							for (String s : button_selectedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “button.png" Sprite
							List<String> buttonSprite = new ArrayList<>();
							buttonSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_ui2.png"));
							buttonSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button_ui1.png"));
							File buttonSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/button.png");
							ImageIO.write(NullcoreColor.createNewSprite(buttonSprite, rawColors7), "PNG",
									buttonSpritePath);
							for (String s : buttonSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “confirm.png" Sprite
							List<String> confirmSprite = new ArrayList<>();
							confirmSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/confirm_ui1.png"));
							File confirmSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/confirm.png");
							ImageIO.write(NullcoreColor.createNewSprite(confirmSprite, rawColors12), "PNG",
									confirmSpritePath);
							for (String s : confirmSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “cancel.png" Sprite
							List<String> cancelSprite = new ArrayList<>();
							cancelSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/cancel_ui1.png"));
							File cancelSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/beacon/cancel.png");
							ImageIO.write(NullcoreColor.createNewSprite(cancelSprite, rawColors12), "PNG",
									cancelSpritePath);
							for (String s : cancelSprite) {
								new File(s).delete();
							}

						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Blast Furnace Sprites
						try {
							// [SPRITE CREATION] - "blast_furnace.png" Sprite
							List<String> blast_furnaceSprite = new ArrayList<>();
							blast_furnaceSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/blast_furnace_ui4.png"));
							blast_furnaceSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/blast_furnace_uia.png"));
							blast_furnaceSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/blast_furnace_ui3.png"));
							blast_furnaceSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/blast_furnace_ui2.png"));
							blast_furnaceSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/blast_furnace_ui1.png"));
							File blast_furnaceSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/blast_furnace.png");
							ImageIO.write(NullcoreColor.createNewSprite(blast_furnaceSprite, rawColors2), "PNG",
									blast_furnaceSpritePath);
							for (String s : blast_furnaceSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “burn_progress.png" Sprite
							List<String> burn_progressSprite = new ArrayList<>();
							burn_progressSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/blast_furnace/burn_progress_ui1.png"));
							File burn_progressSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/blast_furnace/burn_progress.png");
							ImageIO.write(NullcoreColor.createNewSprite(burn_progressSprite, rawColors12), "PNG",
									burn_progressSpritePath);
							for (String s : burn_progressSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “lit_progress.png" Sprite
							List<String> lit_progressSprite = new ArrayList<>();
							lit_progressSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/blast_furnace/lit_progress_ui1.png"));
							File lit_progressSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/blast_furnace/lit_progress.png");
							ImageIO.write(NullcoreColor.createNewSprite(lit_progressSprite, rawColors12), "PNG",
									lit_progressSpritePath);
							for (String s : lit_progressSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Brewing Stand Sprites
						try {
							// [SPRITE CREATION] - "brewing_stand.png" Sprite
							List<String> brewing_standSprite = new ArrayList<>();
							brewing_standSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/brewing_stand_ui4.png"));
							brewing_standSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/brewing_stand_uia.png"));
							brewing_standSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/brewing_stand_ui3.png"));
							brewing_standSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/brewing_stand_ui2.png"));
							brewing_standSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/brewing_stand_ui1.png"));
							File brewing_standSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/brewing_stand.png");
							ImageIO.write(NullcoreColor.createNewSprite(brewing_standSprite, rawColors2), "PNG",
									brewing_standSpritePath);
							for (String s : brewing_standSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “brew_progress.png" Sprite
							List<String> brew_progressSprite = new ArrayList<>();
							brew_progressSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/brewing_stand/brew_progress_ui1.png"));
							File brew_progressSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/brewing_stand/brew_progress.png");
							ImageIO.write(NullcoreColor.createNewSprite(brew_progressSprite, rawColors12), "PNG",
									brew_progressSpritePath);
							for (String s : brew_progressSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “bubbles.png" Sprite
							List<String> bubblesSprite = new ArrayList<>();
							bubblesSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/brewing_stand/bubbles_ui1.png"));
							File bubblesSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/brewing_stand/bubbles.png");
							ImageIO.write(NullcoreColor.createNewSprite(bubblesSprite, rawColors12), "PNG",
									bubblesSpritePath);
							for (String s : bubblesSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “fuel_length.png" Sprite
							List<String> fuel_lengthSprite = new ArrayList<>();
							fuel_lengthSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/brewing_stand/fuel_length_ui1.png"));
							File fuel_lengthSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/brewing_stand/fuel_length.png");
							ImageIO.write(NullcoreColor.createNewSprite(fuel_lengthSprite, rawColors12), "PNG",
									fuel_lengthSpritePath);
							for (String s : fuel_lengthSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Cartography Table Sprites
						try {
							// [SPRITE CREATION] - "cartography_table.png" Sprite
							List<String> cartography_tableSprite = new ArrayList<>();
							cartography_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/cartography_table_ui4.png"));
							cartography_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/cartography_table_uia.png"));
							cartography_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/cartography_table_ui3.png"));
							cartography_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/cartography_table_ui2.png"));
							cartography_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/cartography_table_ui1.png"));
							File cartography_tableSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/cartography_table.png");
							ImageIO.write(NullcoreColor.createNewSprite(cartography_tableSprite, rawColors2), "PNG",
									cartography_tableSpritePath);
							for (String s : cartography_tableSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “error.png" Sprite
							List<String> errorSprite = new ArrayList<>();
							errorSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/cartography_table/error_ui1.png"));
							errorSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/cartography_table/error_ui2.png"));
							File errorSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/cartography_table/error.png");
							ImageIO.write(NullcoreColor.createNewSprite(errorSprite, rawColors11), "PNG",
									errorSpritePath);
							for (String s : errorSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Crafter Sprites
						try {
							// [SPRITE CREATION] - "crafter.png" Sprite
							List<String> crafterSprite = new ArrayList<>();
							crafterSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafter_ui4.png"));
							crafterSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafter_uia.png"));
							crafterSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafter_ui3.png"));
							crafterSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafter_ui2.png"));
							crafterSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafter_ui1.png"));
							File crafterSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/crafter.png");
							ImageIO.write(NullcoreColor.createNewSprite(crafterSprite, rawColors2), "PNG",
									crafterSpritePath);
							for (String s : crafterSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “disabled_slot.png" Sprite
							List<String> disabled_slotSprite = new ArrayList<>();
							disabled_slotSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/crafter/disabled_slot_ui2.png"));
							disabled_slotSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/crafter/disabled_slot_ui1.png"));
							File disabled_slotSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/crafter/disabled_slot.png");
							ImageIO.write(NullcoreColor.createNewSprite(disabled_slotSprite, rawColors6), "PNG",
									disabled_slotSpritePath);
							for (String s : disabled_slotSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Creative Inventory Sprites
						try {
							// [SPRITE CREATION] - “tab_inventory.png" Sprite
							List<String> tab_inventorySprite = new ArrayList<>();
							tab_inventorySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_inventory_ui4.png"));
							tab_inventorySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_inventory_uia.png"));
							tab_inventorySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_inventory_ui3.png"));
							tab_inventorySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_inventory_ui2.png"));
							tab_inventorySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_inventory_ui1.png"));
							File tab_inventorySpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_inventory.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_inventorySprite, rawColors2), "PNG",
									tab_inventorySpritePath);
							for (String s : tab_inventorySprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_item_search.png" Sprite
							List<String> tab_item_searchSprite = new ArrayList<>();
							tab_item_searchSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_item_search_ui4.png"));
							tab_item_searchSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_item_search_ui3.png"));
							tab_item_searchSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_item_search_ui2.png"));
							tab_item_searchSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_item_search_ui1.png"));
							File tab_item_searchSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_item_search.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_item_searchSprite, rawColors4), "PNG",
									tab_item_searchSpritePath);
							for (String s : tab_item_searchSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_items.png" Sprite
							List<String> tab_itemsSprite = new ArrayList<>();
							tab_itemsSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_items_ui4.png"));
							tab_itemsSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_items_ui3.png"));
							tab_itemsSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_items_ui2.png"));
							tab_itemsSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_items_ui1.png"));
							File tab_itemsSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/creative_inventory/tab_items.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_itemsSprite, rawColors4), "PNG",
									tab_itemsSpritePath);
							for (String s : tab_itemsSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “scroller_disabled.png" Sprite
							List<String> scroller_disabledSprite = new ArrayList<>();
							scroller_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/scroller_disabled_ui2.png"));
							scroller_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/scroller_disabled_ui1.png"));
							File scroller_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/scroller_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(scroller_disabledSprite, rawColors5), "PNG",
									scroller_disabledSpritePath);
							for (String s : scroller_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “scroller.png" Sprite
							List<String> scrollerSprite = new ArrayList<>();
							scrollerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/scroller_ui2.png"));
							scrollerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/scroller_ui1.png"));
							File scrollerSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/scroller.png");
							ImageIO.write(NullcoreColor.createNewSprite(scrollerSprite, rawColors7), "PNG",
									scrollerSpritePath);
							for (String s : scrollerSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_selected_1.png" Sprite
							List<String> tab_bottom_selected_1Sprite = new ArrayList<>();
							tab_bottom_selected_1Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_1_ui2.png"));
							tab_bottom_selected_1Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_1_ui1.png"));
							File tab_bottom_selected_1SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_1.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_selected_1Sprite, rawColors6), "PNG",
									tab_bottom_selected_1SpritePath);
							for (String s : tab_bottom_selected_1Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_selected_2.png" Sprite
							List<String> tab_bottom_selected_2Sprite = new ArrayList<>();
							tab_bottom_selected_2Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_2_ui2.png"));
							tab_bottom_selected_2Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_2_ui1.png"));
							File tab_bottom_selected_2SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_2.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_selected_2Sprite, rawColors6), "PNG",
									tab_bottom_selected_2SpritePath);
							for (String s : tab_bottom_selected_2Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_selected_3.png" Sprite
							List<String> tab_bottom_selected_3Sprite = new ArrayList<>();
							tab_bottom_selected_3Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_3_ui2.png"));
							tab_bottom_selected_3Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_3_ui1.png"));
							File tab_bottom_selected_3SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_3.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_selected_3Sprite, rawColors6), "PNG",
									tab_bottom_selected_3SpritePath);
							for (String s : tab_bottom_selected_3Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_selected_4.png" Sprite
							List<String> tab_bottom_selected_4Sprite = new ArrayList<>();
							tab_bottom_selected_4Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_4_ui2.png"));
							tab_bottom_selected_4Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_4_ui1.png"));
							File tab_bottom_selected_4SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_4.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_selected_4Sprite, rawColors6), "PNG",
									tab_bottom_selected_4SpritePath);
							for (String s : tab_bottom_selected_4Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_selected_5.png" Sprite
							List<String> tab_bottom_selected_5Sprite = new ArrayList<>();
							tab_bottom_selected_5Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_5_ui2.png"));
							tab_bottom_selected_5Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_5_ui1.png"));
							File tab_bottom_selected_5SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_5.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_selected_5Sprite, rawColors6), "PNG",
									tab_bottom_selected_5SpritePath);
							for (String s : tab_bottom_selected_5Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_selected_6.png" Sprite
							List<String> tab_bottom_selected_6Sprite = new ArrayList<>();
							tab_bottom_selected_6Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_6_ui2.png"));
							tab_bottom_selected_6Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_6_ui1.png"));
							File tab_bottom_selected_6SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_6.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_selected_6Sprite, rawColors6), "PNG",
									tab_bottom_selected_6SpritePath);
							for (String s : tab_bottom_selected_6Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_selected_7.png" Sprite
							List<String> tab_bottom_selected_7Sprite = new ArrayList<>();
							tab_bottom_selected_7Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_7_ui2.png"));
							tab_bottom_selected_7Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_7_ui1.png"));
							File tab_bottom_selected_7SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_selected_7.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_selected_7Sprite, rawColors6), "PNG",
									tab_bottom_selected_7SpritePath);
							for (String s : tab_bottom_selected_7Sprite) {
								new File(s).delete();
							}

							// [SPRITE CREATION] - “tab_bottom_unselected_1.png" Sprite
							List<String> tab_bottom_unselected_1Sprite = new ArrayList<>();
							tab_bottom_unselected_1Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_1_ui2.png"));
							tab_bottom_unselected_1Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_1_ui1.png"));
							File tab_bottom_unselected_1SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_1.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_unselected_1Sprite, rawColors5),
									"PNG",
									tab_bottom_unselected_1SpritePath);
							for (String s : tab_bottom_unselected_1Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_unselected_2.png" Sprite
							List<String> tab_bottom_unselected_2Sprite = new ArrayList<>();
							tab_bottom_unselected_2Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_2_ui2.png"));
							tab_bottom_unselected_2Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_2_ui1.png"));
							File tab_bottom_unselected_2SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_2.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_unselected_2Sprite, rawColors5),
									"PNG",
									tab_bottom_unselected_2SpritePath);
							for (String s : tab_bottom_unselected_2Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_unselected_3.png" Sprite
							List<String> tab_bottom_unselected_3Sprite = new ArrayList<>();
							tab_bottom_unselected_3Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_3_ui2.png"));
							tab_bottom_unselected_3Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_3_ui1.png"));
							File tab_bottom_unselected_3SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_3.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_unselected_3Sprite, rawColors5),
									"PNG",
									tab_bottom_unselected_3SpritePath);
							for (String s : tab_bottom_unselected_3Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_unselected_4.png" Sprite
							List<String> tab_bottom_unselected_4Sprite = new ArrayList<>();
							tab_bottom_unselected_4Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_4_ui2.png"));
							tab_bottom_unselected_4Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_4_ui1.png"));
							File tab_bottom_unselected_4SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_4.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_unselected_4Sprite, rawColors5),
									"PNG",
									tab_bottom_unselected_4SpritePath);
							for (String s : tab_bottom_unselected_4Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_unselected_5.png" Sprite
							List<String> tab_bottom_unselected_5Sprite = new ArrayList<>();
							tab_bottom_unselected_5Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_5_ui2.png"));
							tab_bottom_unselected_5Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_5_ui1.png"));
							File tab_bottom_unselected_5SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_5.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_unselected_5Sprite, rawColors5),
									"PNG",
									tab_bottom_unselected_5SpritePath);
							for (String s : tab_bottom_unselected_5Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_unselected_6.png" Sprite
							List<String> tab_bottom_unselected_6Sprite = new ArrayList<>();
							tab_bottom_unselected_6Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_6_ui2.png"));
							tab_bottom_unselected_6Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_6_ui1.png"));
							File tab_bottom_unselected_6SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_6.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_unselected_6Sprite, rawColors5),
									"PNG",
									tab_bottom_unselected_6SpritePath);
							for (String s : tab_bottom_unselected_6Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “tab_bottom_unselected_7.png" Sprite
							List<String> tab_bottom_unselected_7Sprite = new ArrayList<>();
							tab_bottom_unselected_7Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_7_ui2.png"));
							tab_bottom_unselected_7Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_7_ui1.png"));
							File tab_bottom_unselected_7SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/creative_inventory/tab_bottom_unselected_7.png");
							ImageIO.write(NullcoreColor.createNewSprite(tab_bottom_unselected_7Sprite, rawColors5),
									"PNG",
									tab_bottom_unselected_7SpritePath);
							for (String s : tab_bottom_unselected_7Sprite) {
								new File(s).delete();
							}

						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Enchantment table Sprites
						try {
							// [SPRITE CREATION] - “enchanting_table.png" Sprite
							List<String> enchanting_tableSprite = new ArrayList<>();
							enchanting_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/enchanting_table_ui4.png"));
							enchanting_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/enchanting_table_uia.png"));
							enchanting_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/enchanting_table_ui3.png"));
							enchanting_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/enchanting_table_ui2.png"));
							enchanting_tableSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/enchanting_table_ui1.png"));
							File enchanting_tableSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/enchanting_table.png");
							ImageIO.write(NullcoreColor.createNewSprite(enchanting_tableSprite, rawColors2), "PNG",
									enchanting_tableSpritePath);
							for (String s : enchanting_tableSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “enchantment_slot_disabled.png" Sprite
							List<String> enchantment_slot_disabledSprite = new ArrayList<>();
							enchantment_slot_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/enchantment_slot_disabled_ui2.png"));
							enchantment_slot_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/enchantment_slot_disabled_ui1.png"));
							File enchantment_slot_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/enchantment_slot_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(enchantment_slot_disabledSprite, rawColors5),
									"PNG",
									enchantment_slot_disabledSpritePath);
							for (String s : enchantment_slot_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “enchantment_slot_highlighted.png" Sprite
							List<String> enchantment_slot_highlightedSprite = new ArrayList<>();
							enchantment_slot_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/enchantment_slot_highlighted_ui2.png"));
							enchantment_slot_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/enchantment_slot_highlighted_ui1.png"));
							File enchantment_slot_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/enchantment_slot_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(enchantment_slot_highlightedSprite, rawColors10),
									"PNG", enchantment_slot_highlightedSpritePath);
							for (String s : enchantment_slot_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “enchantment_slot.png" Sprite
							List<String> enchantment_slotSprite = new ArrayList<>();
							enchantment_slotSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/enchantment_slot_ui2.png"));
							enchantment_slotSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/enchantment_slot_ui1.png"));
							File enchantment_slotSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/enchantment_slot.png");
							ImageIO.write(NullcoreColor.createNewSprite(enchantment_slotSprite, rawColors7), "PNG",
									enchantment_slotSpritePath);
							for (String s : enchantment_slotSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “level_1_disabled.png" Sprite
							List<String> level_1_disabledSprite = new ArrayList<>();
							level_1_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_1_disabled_ui1.png"));
							File level_1_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_1_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(level_1_disabledSprite, rawColors13), "PNG",
									level_1_disabledSpritePath);
							for (String s : level_1_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “level_2_disabled.png" Sprite
							List<String> level_2_disabledSprite = new ArrayList<>();
							level_2_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_2_disabled_ui1.png"));
							File level_2_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_2_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(level_2_disabledSprite, rawColors13), "PNG",
									level_2_disabledSpritePath);
							for (String s : level_2_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “level_3_disabled.png" Sprite
							List<String> level_3_disabledSprite = new ArrayList<>();
							level_3_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_3_disabled_ui1.png"));
							File level_3_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_3_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(level_3_disabledSprite, rawColors13), "PNG",
									level_3_disabledSpritePath);
							for (String s : level_3_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “level_1.png" Sprite
							List<String> level_1Sprite = new ArrayList<>();
							level_1Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_1_ui1.png"));
							File level_1SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_1.png");
							ImageIO.write(NullcoreColor.createNewSprite(level_1Sprite, rawColors12), "PNG",
									level_1SpritePath);
							for (String s : level_1Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “level_2.png" Sprite
							List<String> level_2Sprite = new ArrayList<>();
							level_2Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_2_ui1.png"));
							File level_2SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_2.png");
							ImageIO.write(NullcoreColor.createNewSprite(level_2Sprite, rawColors12), "PNG",
									level_2SpritePath);
							for (String s : level_2Sprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “level_3.png" Sprite
							List<String> level_3Sprite = new ArrayList<>();
							level_3Sprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_3_ui1.png"));
							File level_3SpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/enchanting_table/level_3.png");
							ImageIO.write(NullcoreColor.createNewSprite(level_3Sprite, rawColors12), "PNG",
									level_3SpritePath);
							for (String s : level_3Sprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Furnace Sprites
						try {
							// [SPRITE CREATION] - “furnace.png" Sprite
							List<String> furnaceSprite = new ArrayList<>();
							furnaceSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/furnace_ui4.png"));
							furnaceSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/furnace_uia.png"));
							furnaceSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/furnace_ui3.png"));
							furnaceSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/furnace_ui2.png"));
							furnaceSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/furnace_ui1.png"));
							File furnaceSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/furnace.png");
							ImageIO.write(NullcoreColor.createNewSprite(furnaceSprite, rawColors2), "PNG",
									furnaceSpritePath);
							for (String s : furnaceSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “burn_progress.png" Sprite
							List<String> burn_progressSprite = new ArrayList<>();
							burn_progressSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/furnace/burn_progress_ui1.png"));
							File burn_progressSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/furnace/burn_progress.png");
							ImageIO.write(NullcoreColor.createNewSprite(burn_progressSprite, rawColors12), "PNG",
									burn_progressSpritePath);
							for (String s : burn_progressSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “lit_progress.png" Sprite
							List<String> lit_progressSprite = new ArrayList<>();
							lit_progressSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/furnace/lit_progress_ui1.png"));
							File lit_progressSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/furnace/lit_progress.png");
							ImageIO.write(NullcoreColor.createNewSprite(lit_progressSprite, rawColors12), "PNG",
									lit_progressSpritePath);
							for (String s : lit_progressSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Grindstone Sprites
						try {
							// [SPRITE CREATION] - “grindstone.png" Sprite
							List<String> grindstoneSprite = new ArrayList<>();
							grindstoneSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/grindstone_ui4.png"));
							grindstoneSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/grindstone_ui3.png"));
							grindstoneSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/grindstone_ui2.png"));
							grindstoneSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/grindstone_ui1.png"));
							File grindstoneSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/grindstone.png");
							ImageIO.write(NullcoreColor.createNewSprite(grindstoneSprite, rawColors4), "PNG",
									grindstoneSpritePath);
							for (String s : grindstoneSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “error.png" Sprite
							List<String> errorSprite = new ArrayList<>();
							errorSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/grindstone/error_ui1.png"));
							errorSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/grindstone/error_ui2.png"));
							File errorSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/grindstone/error.png");
							ImageIO.write(NullcoreColor.createNewSprite(errorSprite, rawColors11), "PNG",
									errorSpritePath);
							for (String s : errorSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Horse Sprites
						try {
							// [SPRITE CREATION] - “horse.png" Sprite
							List<String> horseSprite = new ArrayList<>();
							horseSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/horse_ui4.png"));
							horseSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/horse_ui3.png"));
							horseSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/horse_ui2.png"));
							horseSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/horse_ui1.png"));
							File horseSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/horse.png");
							ImageIO.write(NullcoreColor.createNewSprite(horseSprite, rawColors4), "PNG",
									horseSpritePath);
							for (String s : horseSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “chest_slots.png" Sprite
							List<String> chest_slotsSprite = new ArrayList<>();
							chest_slotsSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/horse/chest_slots_ui2.png"));
							chest_slotsSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/horse/chest_slots_ui1.png"));
							File chest_slotsSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/horse/chest_slots.png");
							ImageIO.write(NullcoreColor.createNewSprite(chest_slotsSprite, rawColors5), "PNG",
									chest_slotsSpritePath);
							for (String s : chest_slotsSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Inventory Sprites
						try {
							// [SPRITE CREATION] - “inventory.png" Sprite
							List<String> inventorySprite = new ArrayList<>();
							inventorySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/inventory_ui4.png"));
							inventorySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/inventory_uia.png"));
							inventorySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/inventory_ui3.png"));
							inventorySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/inventory_ui2.png"));
							inventorySprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/inventory_ui1.png"));
							File inventorySpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/inventory.png");
							ImageIO.write(NullcoreColor.createNewSprite(inventorySprite, rawColors2), "PNG",
									inventorySpritePath);
							for (String s : inventorySprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “effect_background_large.png" Sprite
							List<String> effect_background_largeSprite = new ArrayList<>();
							effect_background_largeSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/inventory/effect_background_large_ui2.png"));
							effect_background_largeSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/inventory/effect_background_large_ui1.png"));
							File effect_background_largeSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/inventory/effect_background_large.png");
							ImageIO.write(NullcoreColor.createNewSprite(effect_background_largeSprite, rawColors6),
									"PNG",
									effect_background_largeSpritePath);
							for (String s : effect_background_largeSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “effect_background_small.png" Sprite
							List<String> effect_background_smallSprite = new ArrayList<>();
							effect_background_smallSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/inventory/effect_background_small_ui2.png"));
							effect_background_smallSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/inventory/effect_background_small_ui1.png"));
							File effect_background_smallSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/inventory/effect_background_small.png");
							ImageIO.write(NullcoreColor.createNewSprite(effect_background_smallSprite, rawColors6),
									"PNG",
									effect_background_smallSpritePath);
							for (String s : effect_background_smallSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Loom Sprites
						try {
							// [SPRITE CREATION] - “loom.png" Sprite
							List<String> loomSprite = new ArrayList<>();
							loomSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/loom_ui4.png"));
							loomSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/loom_uia.png"));
							loomSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/loom_ui3.png"));
							loomSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/loom_ui2.png"));
							loomSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/loom_ui1.png"));
							File loomSpritePath = new File(
									currentDirect
											+ "/new_smc_pack/assets/minecraft/textures/gui/container/loom.png");
							ImageIO.write(NullcoreColor.createNewSprite(loomSprite, rawColors2), "PNG", loomSpritePath);
							for (String s : loomSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “pattern_highlighted.png" Sprite
							List<String> pattern_highlightedSprite = new ArrayList<>();
							pattern_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/pattern_highlighted_ui2.png"));
							pattern_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/pattern_highlighted_ui1.png"));
							File pattern_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/pattern_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(pattern_highlightedSprite, rawColors10), "PNG",
									pattern_highlightedSpritePath);
							for (String s : pattern_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “pattern_selected.png" Sprite
							List<String> pattern_selectedSprite = new ArrayList<>();
							pattern_selectedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/pattern_selected_ui2.png"));
							pattern_selectedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/pattern_selected_ui1.png"));
							File pattern_selectedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/pattern_selected.png");
							ImageIO.write(NullcoreColor.createNewSprite(pattern_selectedSprite, rawColors5), "PNG",
									pattern_selectedSpritePath);
							for (String s : pattern_selectedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “pattern.png" Sprite
							List<String> patternSprite = new ArrayList<>();
							patternSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/pattern_ui2.png"));
							patternSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/pattern_ui1.png"));
							File patternSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/pattern.png");
							ImageIO.write(NullcoreColor.createNewSprite(patternSprite, rawColors7), "PNG",
									patternSpritePath);
							for (String s : patternSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “scroller_disabled.png" Sprite
							List<String> scroller_disabledSprite = new ArrayList<>();
							scroller_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/scroller_disabled_ui2.png"));
							scroller_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/scroller_disabled_ui1.png"));
							File scroller_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/scroller_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(scroller_disabledSprite, rawColors6), "PNG",
									scroller_disabledSpritePath);
							for (String s : scroller_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “scroller.png" Sprite
							List<String> scrollerSprite = new ArrayList<>();
							scrollerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/scroller_ui2.png"));
							scrollerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/scroller_ui1.png"));
							File scrollerSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/loom/scroller.png");
							ImageIO.write(NullcoreColor.createNewSprite(scrollerSprite, rawColors7), "PNG",
									scrollerSpritePath);
							for (String s : scrollerSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Smithing Table Sprites
						try {
							// [SPRITE CREATION] - “smithing.png" Sprite
							List<String> smithingSprite = new ArrayList<>();
							smithingSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smithing_ui4.png"));
							smithingSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smithing_uia.png"));
							smithingSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smithing_ui3.png"));
							smithingSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smithing_ui2.png"));
							smithingSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smithing_ui1.png"));
							File smithingSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smithing.png");
							ImageIO.write(NullcoreColor.createNewSprite(smithingSprite, rawColors2), "PNG",
									smithingSpritePath);
							for (String s : smithingSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “error.png" Sprite
							List<String> errorSprite = new ArrayList<>();
							errorSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/smithing/error_ui2.png"));
							errorSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/smithing/error_ui1.png"));
							File errorSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/smithing/error.png");
							ImageIO.write(NullcoreColor.createNewSprite(errorSprite, rawColors11), "PNG",
									errorSpritePath);
							for (String s : errorSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Smoker Sprites
						try {
							// [SPRITE CREATION] - “smoker.png" Sprite
							List<String> smokerSprite = new ArrayList<>();
							smokerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smoker_ui4.png"));
							smokerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smoker_uia.png"));
							smokerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smoker_ui3.png"));
							smokerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smoker_ui2.png"));
							smokerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smoker_ui1.png"));
							File smokerSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/smoker.png");
							ImageIO.write(NullcoreColor.createNewSprite(smokerSprite, rawColors2), "PNG",
									smokerSpritePath);
							for (String s : smokerSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “burn_progress.png" Sprite
							List<String> burn_progressSprite = new ArrayList<>();
							burn_progressSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/smoker/burn_progress_ui1.png"));
							File burn_progressSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/smoker/burn_progress.png");
							ImageIO.write(NullcoreColor.createNewSprite(burn_progressSprite, rawColors12), "PNG",
									burn_progressSpritePath);
							for (String s : burn_progressSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “lit_progress.png" Sprite
							List<String> lit_progressSprite = new ArrayList<>();
							lit_progressSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/smoker/lit_progress_ui1.png"));
							File lit_progressSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/smoker/lit_progress.png");
							ImageIO.write(NullcoreColor.createNewSprite(lit_progressSprite, rawColors12), "PNG",
									lit_progressSpritePath);
							for (String s : lit_progressSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Stonecutter Sprites
						try {
							// [SPRITE CREATION] - “stonecutter.png" Sprite
							List<String> stonecutterSprite = new ArrayList<>();
							stonecutterSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/stonecutter_ui4.png"));
							stonecutterSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/stonecutter_uia.png"));
							stonecutterSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/stonecutter_ui3.png"));
							stonecutterSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/stonecutter_ui2.png"));
							stonecutterSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/stonecutter_ui1.png"));
							File stonecutterSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/stonecutter.png");
							ImageIO.write(NullcoreColor.createNewSprite(stonecutterSprite, rawColors2), "PNG",
									stonecutterSpritePath);
							for (String s : stonecutterSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “recipe_highlighted.png" Sprite
							List<String> recipe_highlightedSprite = new ArrayList<>();
							recipe_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/recipe_highlighted_ui2.png"));
							recipe_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/recipe_highlighted_ui1.png"));
							File recipe_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/recipe_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(recipe_highlightedSprite, rawColors10), "PNG",
									recipe_highlightedSpritePath);
							for (String s : recipe_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “recipe_selected.png" Sprite
							List<String> recipe_selectedSprite = new ArrayList<>();
							recipe_selectedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/recipe_selected_ui2.png"));
							recipe_selectedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/recipe_selected_ui1.png"));
							File recipe_selectedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/recipe_selected.png");
							ImageIO.write(NullcoreColor.createNewSprite(recipe_selectedSprite, rawColors6), "PNG",
									recipe_selectedSpritePath);
							for (String s : recipe_selectedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “recipe.png" Sprite
							List<String> recipeSprite = new ArrayList<>();
							recipeSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/recipe_ui2.png"));
							recipeSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/recipe_ui1.png"));
							File recipeSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/recipe.png");
							ImageIO.write(NullcoreColor.createNewSprite(recipeSprite, rawColors7), "PNG",
									recipeSpritePath);
							for (String s : recipeSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “scroller_disabled.png" Sprite
							List<String> scroller_disabledSprite = new ArrayList<>();
							scroller_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/scroller_disabled_ui2.png"));
							scroller_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/scroller_disabled_ui1.png"));
							File scroller_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/scroller_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(scroller_disabledSprite, rawColors6), "PNG",
									scroller_disabledSpritePath);
							for (String s : scroller_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “scroller.png" Sprite
							List<String> scrollerSprite = new ArrayList<>();
							scrollerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/scroller_ui2.png"));
							scrollerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/scroller_ui1.png"));
							File scrollerSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/stonecutter/scroller.png");
							ImageIO.write(NullcoreColor.createNewSprite(scrollerSprite, rawColors7), "PNG",
									scrollerSpritePath);
							for (String s : scrollerSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Villager Sprites
						try {
							// [SPRITE CREATION] - “villager.png" Sprite
							List<String> villagerSprite = new ArrayList<>();
							villagerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/villager_ui4.png"));
							villagerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/villager_ui3.png"));
							villagerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/villager_ui2.png"));
							villagerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/villager_ui1.png"));
							File villagerSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/container/villager.png");
							ImageIO.write(NullcoreColor.createNewSprite(villagerSprite, rawColors4), "PNG",
									villagerSpritePath);
							for (String s : villagerSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “discount_strike_through.png" Sprite
							List<String> discount_strikethroughSprite = new ArrayList<>();
							discount_strikethroughSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/discount_strikethrough_ui1.png"));
							File discount_strikethroughSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/discount_strikethrough.png");
							ImageIO.write(NullcoreColor.createNewSprite(discount_strikethroughSprite, rawColors13),
									"PNG",
									discount_strikethroughSpritePath);
							for (String s : discount_strikethroughSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “experience_bar_background.png" Sprite
							List<String> experience_bar_backgroundSprite = new ArrayList<>();
							experience_bar_backgroundSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/experience_bar_background_ui2.png"));
							experience_bar_backgroundSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/experience_bar_background_ui1.png"));
							File experience_bar_backgroundSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/experience_bar_background.png");
							ImageIO.write(NullcoreColor.createNewSprite(experience_bar_backgroundSprite, rawColors5),
									"PNG",
									experience_bar_backgroundSpritePath);
							for (String s : experience_bar_backgroundSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “experience_bar_current.png" Sprite
							List<String> experience_bar_currentSprite = new ArrayList<>();
							experience_bar_currentSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/experience_bar_current_ui2.png"));
							experience_bar_currentSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/experience_bar_current_ui1.png"));
							File experience_bar_currentSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/experience_bar_current.png");
							ImageIO.write(NullcoreColor.createNewSprite(experience_bar_currentSprite, rawColors11),
									"PNG",
									experience_bar_currentSpritePath);
							for (String s : experience_bar_currentSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “experience_bar_result.png" Sprite
							List<String> out_of_stockSprite = new ArrayList<>();
							out_of_stockSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/out_of_stock_ui2.png"));
							out_of_stockSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/out_of_stock_ui1.png"));
							File out_of_stockSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/out_of_stock.png");
							ImageIO.write(NullcoreColor.createNewSprite(out_of_stockSprite, rawColors11), "PNG",
									out_of_stockSpritePath);
							for (String s : out_of_stockSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “scroller_disabled.png" Sprite
							List<String> scroller_disabledSprite = new ArrayList<>();
							scroller_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/scroller_disabled_ui2.png"));
							scroller_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/scroller_disabled_ui1.png"));
							File scroller_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/scroller_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(scroller_disabledSprite, rawColors5), "PNG",
									scroller_disabledSpritePath);
							for (String s : scroller_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “scroller.png" Sprite
							List<String> scrollerSprite = new ArrayList<>();
							scrollerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/scroller_ui2.png"));
							scrollerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/scroller_ui1.png"));
							File scrollerSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/scroller.png");
							ImageIO.write(NullcoreColor.createNewSprite(scrollerSprite, rawColors7), "PNG",
									scrollerSpritePath);
							for (String s : scrollerSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “trade_arrow_out_of_stock.png" Sprite
							List<String> trade_arrow_out_of_stockSprite = new ArrayList<>();
							trade_arrow_out_of_stockSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/trade_arrow_out_of_stock_ui2.png"));
							trade_arrow_out_of_stockSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/trade_arrow_out_of_stock_ui1.png"));
							File trade_arrow_out_of_stockSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/trade_arrow_out_of_stock.png");
							ImageIO.write(NullcoreColor.createNewSprite(trade_arrow_out_of_stockSprite, rawColors11),
									"PNG",
									trade_arrow_out_of_stockSpritePath);
							for (String s : trade_arrow_out_of_stockSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “trade_arrow.png" Sprite
							List<String> trade_arrowSprite = new ArrayList<>();
							trade_arrowSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/trade_arrow_ui1.png"));
							File trade_arrowSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/villager/trade_arrow.png");
							ImageIO.write(NullcoreColor.createNewSprite(trade_arrowSprite, rawColors12), "PNG",
									trade_arrowSpritePath);
							for (String s : trade_arrowSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Slot Sprites
						try {
							// [SPRITE CREATION] - “slot.png" Sprite
							List<String> slotSprite = new ArrayList<>();
							slotSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/slot_ui2.png"));
							slotSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/slot_ui1.png"));
							File slotSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/container/slot.png");
							ImageIO.write(NullcoreColor.createNewSprite(slotSprite, rawColors5), "PNG", slotSpritePath);
							for (String s : slotSprite) {
								new File(s).delete();
							}
						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [SPRITE CREATION] - All Widget Sprites Sprites
						try {
							// [SPRITE CREATION] - “button_disabled.png" Sprite
							List<String> button_disabledSprite = new ArrayList<>();
							button_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/button_disabled_ui2.png"));
							button_disabledSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/button_disabled_ui1.png"));
							File button_disabledSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/button_disabled.png");
							ImageIO.write(NullcoreColor.createNewSprite(button_disabledSprite, rawColors5), "PNG",
									button_disabledSpritePath);
							for (String s : button_disabledSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “button_highlighted.png" Sprite
							List<String> button_highlightedSprite = new ArrayList<>();
							button_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/button_highlighted_ui2.png"));
							button_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/button_highlighted_ui1.png"));
							File button_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/button_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(button_highlightedSprite, rawColors9), "PNG",
									button_highlightedSpritePath);
							for (String s : button_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “button.png" Sprite
							List<String> buttonSprite = new ArrayList<>();
							buttonSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/button_ui2.png"));
							buttonSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/button_ui1.png"));
							File buttonSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/button.png");
							ImageIO.write(NullcoreColor.createNewSprite(buttonSprite, rawColors6), "PNG",
									buttonSpritePath);
							for (String s : buttonSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “scroller.png" Sprite
							List<String> scrollerSprite = new ArrayList<>();
							scrollerSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/scroller_ui1.png"));
							File scrollerSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/scroller.png");
							ImageIO.write(NullcoreColor.createNewSprite(scrollerSprite, rawColors12), "PNG",
									scrollerSpritePath);
							for (String s : scrollerSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “slider_handle_highlighted.png" Sprite
							List<String> slider_handle_highlightedSprite = new ArrayList<>();
							slider_handle_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_handle_highlighted_ui2.png"));
							slider_handle_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_handle_highlighted_ui1.png"));
							File slider_handle_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_handle_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(slider_handle_highlightedSprite, rawColors10),
									"PNG",
									slider_handle_highlightedSpritePath);
							for (String s : slider_handle_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “slider_handle.png" Sprite
							List<String> slider_handleSprite = new ArrayList<>();
							slider_handleSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_handle_ui2.png"));
							slider_handleSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_handle_ui1.png"));
							File slider_handleSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_handle.png");
							ImageIO.write(NullcoreColor.createNewSprite(slider_handleSprite, rawColors7), "PNG",
									slider_handleSpritePath);
							for (String s : slider_handleSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “slider_highlighted.png" Sprite
							List<String> slider_highlightedSprite = new ArrayList<>();
							slider_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_highlighted_ui2.png"));
							slider_highlightedSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_highlighted_ui1.png"));
							File slider_highlightedSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_highlighted.png");
							ImageIO.write(NullcoreColor.createNewSprite(slider_highlightedSprite, rawColors5), "PNG",
									slider_highlightedSpritePath);
							for (String s : slider_highlightedSprite) {
								new File(s).delete();
							}
							// [SPRITE CREATION] - “slider.png" Sprite
							List<String> sliderSprite = new ArrayList<>();
							sliderSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_ui2.png"));
							sliderSprite.add((currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider_ui1.png"));
							File sliderSpritePath = new File(currentDirect
									+ "/new_smc_pack/assets/minecraft/textures/gui/sprites/widget/slider.png");
							ImageIO.write(NullcoreColor.createNewSprite(sliderSprite, rawColors5), "PNG",
									sliderSpritePath);
							for (String s : sliderSprite) {
								new File(s).delete();
							}

						} catch (IOException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						}

						// [PACKAGE] - Names the new file
						String newFileName;
						String originalFileName = "new_smc_pack";
						if (nameInput.getText().length() <= 10 && nameInput.getText().length() >=1 ) {
							newFileName = "Nullcore GUI [" +nameInput.getText()+"] v1.0";
						} else {
							newFileName = "Nullcore GUI [Unnamed Pack] v1.0";
						}

						// [PACKAGE] Determines the location of the new pack, and the user's desktop
						Path sourcePath = Paths.get(originalFileName);
						String userHome = System.getProperty("user.home");
						Path desktopPath = Paths.get(userHome, "Desktop");
						Path destinationPath = desktopPath.resolve(newFileName);
						try {
							Files.move(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
						} catch (IOException e) {
							e.printStackTrace();
						}
						System.exit(0);
					}
				};
			});
			menuPanel1.add(createPack);

			// [MENU] - Sets the window to visible
			menu1.setContentPane(menuPanel1);
			menu1.setVisible(true);
		});
	}

	// [METHOD] - Loads the sprites in the specified folder
	public static List<BufferedImage> loadSpritesFromFolder(String folderPath) throws IOException {
		File folder = new File(folderPath);
		File[] listOfFiles = folder.listFiles();
		List<BufferedImage> sprites = new ArrayList<>();
		if (listOfFiles != null) {
			for (File file : listOfFiles) {
				if (file.isFile() && (file.getName().endsWith(".png"))) {
					sprites.add(ImageIO.read(file));
				}
			}
		}
		return sprites;
	}

	// [METHOD] - Makes a copy of the given file
	public static void copyFile(Path source, Path target) throws IOException {
		Files.walkFileTree(source, new SimpleFileVisitor<Path>() {
			@Override
			public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes bfa) throws IOException {
				Path targetPath = target.resolve(source.relativize(dir));
				if (!Files.exists(targetPath)) {
					Files.createDirectories(targetPath);
				}
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFile(Path file, BasicFileAttributes bfa) throws IOException {
				Files.copy(file, target.resolve(source.relativize(file)), REPLACE_EXISTING);
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
				System.err.println("Failed to visit the following file: " + file + " - " + exc.getMessage());
				return FileVisitResult.CONTINUE;
			}
		});
	}
}

// [METHODS] - Sets the menu background
class MenuBackground extends JPanel {
	private BufferedImage backgroundSprite;

	public MenuBackground(String spritePath) {
		try {
			backgroundSprite = ImageIO.read(new File(spritePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (backgroundSprite != null) {
			g.drawImage(backgroundSprite, 0, 0, getWidth(), getHeight(), this);
		}
	}
}
