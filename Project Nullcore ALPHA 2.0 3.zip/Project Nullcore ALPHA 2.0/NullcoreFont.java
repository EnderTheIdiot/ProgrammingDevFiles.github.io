// -= PROGRAM FONT =-
// Program Name: NullcoreFont (Part of "Project Nullcore ALPHA 2.0")
// Created by: EnderTheIdiot
//
// Font Used: PressStart2P-Regular | by CodeMan38 (Cody Boisclair)
//
// -= INFO =-
// This class allows the main class of this program to use the font file 
// included in this program (PressStart2P). Any changes made will change 
// which font you want the system to use.

import java.awt.Font;
import java.awt.FontFormatException;
import java.io.File;
import java.io.IOException;

public class NullcoreFont {
    // [METHOD] - Returns a font variable from a font file
    public static Font loadSystemFont(String pathToFont, float size) {
        try {
            Font newFont = Font.createFont(Font.TRUETYPE_FONT, new File(pathToFont));
            return newFont.deriveFont(size);
        } catch (IOException | FontFormatException e) {
            e.printStackTrace();
            return new Font("SansSerif", Font.PLAIN, (int) size);
        }
    }
}
