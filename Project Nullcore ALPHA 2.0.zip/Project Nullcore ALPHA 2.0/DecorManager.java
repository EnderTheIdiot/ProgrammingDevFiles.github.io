// -= PROGRAM =-
// Program Name: DecorManager (Part of "Project Nullcore ALPHA 2.0")
// Date Created: 4/17/2026
// Created by: EnderTheIdiot 
//
//
// -= INFO =-
// This class is used to color the files given by the NullcoreMain class.
// Requires the main class to temporarliy hand over the new sprite, along 
// with the sprite color info, the type of GUI sprite (Inventory, Workbench, 
// Menu, etc), and the selected decor to be added to the sprite.
//


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

public class DecorManager {
    public static void decorManager(BufferedImage spriteImage, String spriteColor, int guiType, int selectedDecor) {
    }
}