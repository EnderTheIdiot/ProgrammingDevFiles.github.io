// -= PROGRAM =-
// Program Name: GUIColorizer (Part of "Project Nullcore ALPHA 1.0")
// Date Created: 11/8/2025
// Created by: EnderTheIdiot 
//
//
// -= INFO =-
// This class is used to color the files given by the NullcoreMain class.
// Any modifications to the amount of colors used or the method of coloring can be made here.
//


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

public class GUIColorizer {

    public static BufferedImage createNewSprite(List<String> spritePaths, List<String> guiColors) throws IOException {

        if (spritePaths == null || spritePaths.isEmpty() || spritePaths.size() > 6 ) {
            throw new IllegalArgumentException("Invalid number of images (must be between 1 and 6)");
        }
        if (guiColors == null || guiColors.size() != spritePaths.size()) {
            throw new IllegalArgumentException("Invalid number of images (must be between 1 and 6)");
        }

        List<BufferedImage> sprites = new ArrayList<>();
        int newWidth = 0;
        int newHeight = 0;

        for (int i = spritePaths.size() - 1; i >= 0; i--) {
            File spriteFile = new File(spritePaths.get(i));
            BufferedImage sprite = ImageIO.read(spriteFile);
            applyColor(sprite, guiColors.get(i));
            sprites.add(sprite);
            if (newWidth < sprite.getWidth()) {
                newWidth = sprite.getWidth();
            }
            if (newHeight < sprite.getHeight()) {
                newHeight = sprite.getHeight();
            }
        }

        BufferedImage newGUI = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = newGUI.createGraphics();
        for (BufferedImage sprite : sprites) {
            g.drawImage(sprite, 0, 0, null);
        }
        g.dispose();
        return newGUI;
    }

    private static void applyColor(BufferedImage spriteImage, String spriteColor) {
        Color newColor = Color.decode(spriteColor);
        int targetRGB = newColor.getRGB();

        for (int w = 0; w < spriteImage.getWidth(); w++) {
            for (int h = 0; h < spriteImage.getHeight(); h++) {
                int pixel = spriteImage.getRGB(w, h);
                if ((pixel >> 24) != 0x00) {
                    spriteImage.setRGB(w, h, targetRGB);
                }
            }
        }   
    }
    private static void decorManager(BufferedImage spriteImage, String spriteColor, int guiType, int selectedDecor) {

    }
}
